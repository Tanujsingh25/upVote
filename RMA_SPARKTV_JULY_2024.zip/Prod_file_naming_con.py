import os
import json
import pandas as pd
"""
folder_path = input("Enter INPUT Folder Path :")
files = "C:/Users/23169824/PycharmProjects/pythonProject/" + folder_path + "/"
file = files
i=1
for file in os.listdir(files):
    if not file.startswith("."):
         with open('file_name.json') as json_file:
             dst = json.load(json_file)
             src= file
             print(dst[src])
             os.rename(os.path.join(files,src),os.path.join(files,dst[src]))
             i=+1
"""

folder_path= input("Enter INPUT Folder Path :")
Month_Year=input("Enter INPUT Month+Year :")
mon_year=Month_Year
files = "C:/Users/23169824/PycharmProjects/pythonProject/"+folder_path+"/"
file=files
x=[]
y=[]
New_loc="C:/Users/23169824/PycharmProjects/pythonProject/"+"/"

dict_final_cols = {
  "READYMEDIA_READYMEDIA_LIVETVCHANNEL_RM_ARKTV_LT_1-"+mon_year+".csv": [
    "ARK"
  ],
  "READYMEDIA_READYMEDIA_LIVETVCHANNEL_RM_BABA_LT_01-"+mon_year+".csv": [
    "BABA"
  ],
  "READYMEDIA_READYMEDIA_LIVETVCHANNEL_RM_BBS_LC_1-"+mon_year+".csv": [
    "BBSTV","BBS"
  ],
  "READYMEDIA_READYMEDIA_LIVETVCHANNEL_RM_BTM_LC_01-"+mon_year+".csv": [
    "BTM"
  ],
  "READYMEDIA_READYMEDIA_LIVETVCHANNEL_RM_Bukedde_lc_1-"+mon_year+".csv": [
    "BukeddeTV","BUKEDDE1"
  ],
  "READYMEDIA_READYMEDIA_LIVETVCHANNEL_RM_Channel_44_LT_1-"+mon_year+".csv": [
    "CHANNEL44"
  ],
  "READYMEDIA_READYMEDIA_LIVETVCHANNEL_Delta_Tv_Ltv_01-"+mon_year+".csv": [
    "DELTA","Delta"
  ],
  "READYMEDIA_READYMEDIA_LIVETVCHANNEL_RM_DREAM_LC_01-"+mon_year+".csv": [
    "DREAM","DREAMTV"
  ],
  "READYMEDIA_READYMEDIA_LIVETVCHANNEL_RM_MAGIC1_LC_1-"+mon_year+".csv": [
    "MAGIC 1","Magic1"
  ],
  "READYMEDIA_READYMEDIA_LIVETVCHANNEL_RM_NBS_LC_1-"+mon_year+".csv": [
    "NBS"
  ],
  "READYMEDIA_READYMEDIA_LIVETVCHANNEL_RM_NTV_LC_1-"+mon_year+".csv": [
    "NTV"
  ],
  "READYMEDIA_READYMEDIA_LIVETVCHANNEL_RM_REST_LC_01-"+mon_year+".csv": [
    "REST"
  ],
  "READYMEDIA_READYMEDIA_LIVETVCHANNEL_S24_RM_001-"+mon_year+".csv": [
    "S24"
  ],
  "READYMEDIA_READYMEDIA_LIVETVCHANNEL_Salaam-Tv-LTV-RM-01-"+mon_year+".csv": [
    "SALAM"
  ],
  "READYMEDIA_READYMEDIA_LIVETVCHANNEL_RM_SALT_LC_01-"+mon_year+".csv": [
    "SALT"
  ],
  "READYMEDIA_READYMEDIA_LIVETVCHANNEL_RM_SPARKTV_LC_1-"+mon_year+".csv": [
    "SPARK"
  ],
  "READYMEDIA_READYMEDIA_LIVETVCHANNEL_RM_UBC_LIVE_CHANNEL_1-"+mon_year+".csv": [
    "UBC","ubc"
  ],
  "READYMEDIA_READYMEDIA_LIVETVCHANNEL_RM_UCTV_LT_01-"+mon_year+".csv": [
    "UCTV"
  ],
"READYMEDIA_READYMEDIA_LIVETVCHANNEL_RM_KSTV_LT_01-"+mon_year+".csv": [
    "KSTV","KSTV "
  ],
 "READYMEDIA_READYMEDIA_LIVETVCHANNEL_RM_NYCETV_LT_01-"+mon_year+".csv": [
    "NYCETV","NYCE"
  ],
  "TRACE_TRACE_LIVETVCHANNEL_traceLive_01-"+mon_year+".csv": [
    "TRACE AFRICA EN"
  ],
  "TRACE_TRACE_LIVETVCHANNEL_TRACE_CARIBBEAN_01"+mon_year+".csv": [
    "TRACE CARIBBEAN"
  ],
  "TRACE_TRACE_LIVETVCHANNEL_LiveTvGospe-"+mon_year+".csv": [
    "TRACE GOSPEL ROA"
  ],
  "TRACE_TRACE_LIVETVCHANNEL_miziki_live_tv01-"+mon_year+".csv": [
    "TRACE MZIKI"
  ],
  "TRACE_TRACE_LIVETVCHANNEL_TRACE_URBAN_INT001-"+mon_year+".csv": [
    "TRACE URBAN INT"
  ],
  "TRACE_TRACE_LIVETVCHANNEL_TRACE_SPORT_STARS001-"+mon_year+".csv": [
    "SPORT"
  ]
}



for file in os.listdir(files):
    src = file
    if not file.startswith("."):
        split_file = file.split("_")
        x.append(split_file)
        d=1
        for i in x:
            d=+1
        for j, v in dict_final_cols.items():
            if len(list(set(v) & set(i))) != 0:
                dif = list(set(v) & set(i))
                print(dif)
                os.rename(os.path.join(files, src), os.path.join(files,j))