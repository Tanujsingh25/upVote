import pandas as pd
import time
import re
from csv import reader
#from func_file import *
from dateutil.parser import parse
from datetime import datetime, timedelta, date
from dateutil import relativedelta
import csv
import os
import pyexcel
import xlrd
import logging
import openpyxl
dict_final_cols = {'PROGRAM':["Nom du programme","PROGRAMME NAME","Programme Title","PROGRAM NAME","Program","PROGRAM","programmeName","ï»¿PROGRAM","PROGRAMME NAME","ï»¿PROGRAMME NAME","ï»¿Program","ï»¿PROGRAM NAME","ï»¿PROGRAM","ï»¿PROGAM"],
            'START DATE': ["Date de diffusion","DATE","Date","START DATE","Start Date","Start DATE","Programme Start DATE","ï»¿Date","ï»¿Programme Start DATE","StartDate","Programme Start DATE","ï»¿Programme Start DATE","StartDate(GMT)","ï»¿DATE","START DATE"],
            'START TIME': ["Heure de diffusion","PROGRAMME START","Programme Start Time","Start Time","START TIME","Star Time","StartTime","Programme Start Time","Start Time","Start Time","Star Time","StartTime(GMT)"],
            'END DATE': ["StopDate","EndDate","End Date","EndDate(GMT)"],
            'END TIME': ["End Time","END TIME","StopTime","EndTime","END TIME","End Time","EndTime(GMT)"],
            'LANGUAGE': ["Langue","LANGUAGE", "Language","programme Language","LANGUAGE"],
            'SYNOPSIS': ["Synopsis EN","SYNOPSIS","Programme Synopsis Txt","EPG Synopsis","Synopsis","programme Synopsis Txt FR","Programme Synopsis Txt,","SYNOPSIS"]
           }

#["DATE","Start Date","Date de diffusion","Date","Date ,"]


# Variable secion
type1_check =["Durée","DURATION","programme Duration","Programme Duration","Programme Duration"]
expected = ['PROGRAM' ,'START DATE','START TIME','END DATE','END TIME','LANGUAGE','SYNOPSIS']
format = "%d/%m/%Y"
extra_day_to_add = 0
month_variation_num=0
# Funct
format='%d/%m/%Y'
def format_date_old(date):
    mdate = parse(date).strftime('%d/%m/%Y')
    #print(mdate)
    return mdate
#get_desire_format_date = lambda s_date, format: parse(s_date).strftime(format)

#
def remove_invalid_rows(date,  month_variation=month_variation_num):
    date1 = format_date_old(date)
    #print("date1", date1)
    date_attrs = [int(i) for i in date1.split("/")]
    print("date_attrs[1]",date_attrs[1])
    nextmonth = date.today() + relativedelta.relativedelta(months=month_variation)
    print("nextmonth", nextmonth)
    systm_date = nextmonth.strftime('%d/%m/%Y')

    # today = date.today()
    # systm_date = today.strftime('%d/%m/%Y')

    m = systm_date.split("/")[1]
    m = int(m) + month_variation  # +1 ne
    if m != date_attrs[1]:
        print("Sucessss")





month_variation_num=int(input("ENTER '0' for CURRENT MONTH Vlidations & Next Month vlidations '1':"))
def format_date(date1, month_variation=month_variation_num):
    date1 = format_date_old(date1)
    date_attrs = [int(i) for i in date1.split("/")]

    #nextmonth = date.today() + relativedelta.relativedelta(months=1)
    #print("nextmonth",type(nextmonth))
    #systm_date = nextmonth.strftime('%d/%m/%Y')
    #print("systm_date",systm_date)

    today = date.today()

    #systm_date = systm_date.strftime('%d/%m/%Y')
    systm_date = today.strftime('%d/%m/%Y')

    m = systm_date.split("/")[1]
    m = int(m) + month_variation  # +1 ne

    # m = int(m)
    y = systm_date.split("/")[-1]

    mi = date_attrs.index(m)

    am = date_attrs[mi]

    yi = date_attrs.index(int(y))

    ay = date_attrs[yi]

    di = len(date_attrs) - (yi + mi)
    ad = date_attrs[di]
    if len(str(ad)) == 1:
        ad = '0' + str(ad)
    if len(str(am)) == 1:
        am = '0' + str(am)
    if len(str(ay)) == 2:
        ay = '20' + str(ay)

    return ("/".join([str(ad), str(am), str(ay)]))

def make_correct_format(date, date_wt_mod):
    sday, smonth, syear = date.split("/")
    bfsday, bfsmonth, bfsyear = date_wt_mod.split("/")
    if sday == bfsmonth and bfsday == smonth:
        date = format_date(date_wt_mod, "%m/%d/%Y")
    return date


def format_end_time(date, start_time, end_time, flag):
    if len(start_time.split(':')) == 2:
        start_time += ":00"

    #print("_func_", date, start_time, end_time)
    start_date = datetime.strptime(date + ' ' + start_time, "%d/%m/%Y %H:%M:%S")
    end_date = datetime.strptime(date + ' ' + end_time, "%d/%m/%Y %H:%M:%S")

    if end_date.timestamp() < start_date.timestamp():
        next_date = end_date + timedelta(days=1)
        return next_date.strftime("%d/%m/%Y")
    elif extra_day_to_add and flag:
        next_date = end_date + timedelta(days=extra_day_to_add)
        return next_date.strftime("%d/%m/%Y")
    return start_date.strftime("%d/%m/%Y")


def compute_end_times(start_time):
    end_times = []
    for i in range(1, len(start_time)):
        if len(start_time[i].split(":")) == 2:
            start_time[i] + ":00"
        end_times.append(start_time[i])
    end_times.append("00:00:00")
    return end_times
    # print(end_times)


def compute_end_date(start_date, start_time, end_times, flag):
    end_dates = []
    for i in range(0, len(start_time)):
        end_dates.append(format_end_time(start_date[i], start_time[i], end_times[i], flag))
    #print("end_dates",end_dates)
    return end_dates


def get_start_index(csv_file):
    with open(csv_file) as data:
        reader=csv.reader(data)
        #interestingrows=[row for idx, row in enumerate(reader) if idx==1149094]
        DATE=["Date de diffusion","DATE","Date","START DATE","Start Date"]
        start_index = None
        for idx, row in enumerate(reader):
            #print(idx, row)
            #date=[date for date in DATE if date in row]
            for date in DATE:
                if date in row:
                    start_index = idx
                    break
    #print(start_index)
    return start_index



def convert_epg_data_to_desire_format_type(file):
    file_name = file
    x = "TYPE3"
    frm_start_times = []
    frm_end_times = []
    format = '%d/%m/%Y'
    if file.endswith('xlsx'):
        # Converting Excel to CSV file
        csv_file_name = file.split(".")[0]
        #print(csv_file_name)
        file_name = csv_file_name + ".csv"
        mdf = pd.read_excel(file)
        mdf.to_csv(file_name, encoding='utf-8', index=False, sep=',')
        df = pd.read_csv(file_name)
        df = get_start_index(file_name)
        print("df",df)
        df = pd.read_csv(file_name, skiprows=df)
        df.rename(columns=lambda x: x.strip(), inplace=True)
        #print("df2", df)
        x = [check for check in type1_check if check in df.columns]
        print("X",x)
        #return df



    # Reading CSV file as data frame
    df = get_start_index(file_name)
    print("df22", df)
    df = pd.read_csv(file_name, skiprows=df)
    df.rename(columns=lambda x: x.strip(), inplace=True)
    print(file_name)
    df = pd.read_csv(file_name, encoding='latin1',sep=',')
    df.rename(columns=lambda x: x.strip(), inplace=True)
    #print(df)


    # print(df)
    # Get the file fromat type  : len(x) = 0  --> Type1 Other wise type2

    # formating start date
    print(df.columns)
    date_col = list(set(dict_final_cols['START DATE']).intersection(set(df.columns)))[0]
    print(date_col)
    start_time_col = list(set(dict_final_cols['START TIME']).intersection(set(df.columns)))[0]
    pname_col = list(set(dict_final_cols['PROGRAM']).intersection(set(df.columns)))[0]
    # end_time_col=list(set(dict_final_cols['END TIME']).intersection(set(df.columns)))[0]
    # goes to else
    # end_time_col=list(set(dict_final_cols['END TIME']).intersection(set(df.columns)))[0]
    if x == "TYPE3":
        print("------------TYPE3--------")
        end_time_col = list(set(dict_final_cols['END TIME']).intersection(set(df.columns)))[0]
        print("end_time_col", end_time_col)

        dates = []
        for d in df[date_col]:
            date = format_date(str(d))
            print("date", date)
            # date=make_correct_format(d,date)
            # format_date
            dates.append(date)
        df = df.drop(date_col, axis=1)
        df[date_col] = dates
        #print(df[date_col])
        count = 0
        for dt in range(1, len(dates)):
            # print("dt22",dates[dt],dates[dt-1])
            if datetime.strptime(str(dates[dt]), "%d/%m/%Y") <= datetime.strptime(str(dates[dt - 1]), "%d/%m/%Y"):
                count =count+1
                #print("passss")
                continue
            else:
                if count > 1:
                    print("disorder dates at",dates[dt])


        start_time = []
        for stime in df[start_time_col]:
            if len(stime.split(":")) == 2:
                stime = stime + ":00"
            start_time.append(stime)
        df = df.drop(start_time_col, axis=1)
        df[start_time_col] = start_time
        # print(df[start_time_col])
        # Computing end time and end date
        # frm_start_times = []
        for st in start_time:
            if len(st) == 7:
                st = '0' + st
            s = st.split(":")
            if len(s) == 3:
                st = st[:-3]
            frm_start_times.append(st)

        # end_times = compute_end_times(df[start_time_col])
        # end_times=[]
        for etime in df[end_time_col]:
            if len(etime.split(':')) <= 3:
                etime = etime
            if len(etime) == 7:
                etime = "0" + etime
            if len(etime.split(':')) <= 2:
                etime = etime + ":00"
            frm_end_times.append(etime)
        df = df.drop(end_time_col, axis=1)
        df[end_time_col] = frm_end_times
        end_dates = compute_end_date(df[date_col], df[start_time_col], df[end_time_col], 0)

        # endtime format
        frm_end_times = []
        for et in df[end_time_col]:
            s = et.split(":")
            if len(s) == 3:
                et = et[:-3]
            frm_end_times.append(et)
        df = df.drop(end_time_col, axis=1)
        df[end_time_col] = frm_end_times


    else:

        if len(x) == 0:
            print("TYPE1")
            dates = []

            for d in df[date_col]:
                dates.append(format_date(str(d)))
            df = df.drop(date_col, axis=1)
            df[date_col] = dates

            for dt in range(1,len(dates)):
                #print("dt22",dates[dt],dates[dt-1])
                count = 0
                if datetime.strptime(str(dates[dt]), "%d/%m/%Y") <= datetime.strptime(str(dates[dt-1]), "%d/%m/%Y"):
                    #print("passss")
                    continue
                else:
                    count = count + 1
                    print("COUNT",count)
                    if count >= 1:
                        print("disorder dates at", dates[dt])


            start_time = []
            for stime in df[start_time_col]:
                if len(stime.split(":")) == 2:
                    stime = stime + ":00"
                start_time.append(stime)


            # Computing end time and end date
            #end_times = compute_end_times(df[start_time_col])
            #end_dates = compute_end_date(df[date_col], df[start_time_col], end_times, 0)

            end_times = compute_end_times(start_time)
            end_dates = compute_end_date(df[date_col], df[start_time_col], end_times, 0)

            # Rmoving at the end of time format
            frm_end_times = []
            for et in end_times:
                s = et.split(":")
                if len(s) == 3:
                    et = et[:-3]
                frm_end_times.append(et)

            frm_start_times = []
            for st in df[start_time_col]:
                s = st.split(":")
                if len(s) == 3:
                    st = st[:-3]
                frm_start_times.append(st)
        else:
            # formating start date
            print("TYPE2")
            # end_time_col=list(set(dict_final_cols['END TIME']).intersection(set(df.columns)))[0]
            dates = []

            for d in df[date_col]:
                dates.append(format_date(str(d)))
            #print(date_col)
            df = df.drop(date_col, axis=1)
            df[date_col] = dates
            count = 0
            for dt in range(1,len(dates)):
                #print("dt22",dates[dt],dates[dt-1])
                if datetime.strptime(str(dates[dt]), "%d/%m/%Y") <= datetime.strptime(str(dates[dt-1]), "%d/%m/%Y"):
                    #print("passss")
                    count=count+1
                    continue
                else:
                    if count > 1:
                        print("disorder dates at", dates[dt])

            start_time = []
            for stime in df[start_time_col]:
                if len(stime.split(":")) == 2:
                    stime = stime + ":00"
                start_time.append(stime)

            # Computing end time and end date
            end_times = compute_end_times(start_time)
            end_dates = compute_end_date(df[date_col], df[start_time_col], end_times, 0)
            # end_dates= compute_end_date(df[date_col],df[start_time_col],df[end_time_col],0)

            # start time format
            frm_start_times = []
            for st in start_time:
                s = st.split(":")
                if len(s) == 3:
                    st = st[:-3]
                frm_start_times.append(st)

            # endtime format
            frm_end_times = []
            for et in end_times:
                s = et.split(":")
                if len(s) == 3:
                    et = et[:-3]
                frm_end_times.append(et)

    # Desired output format
    output_df = pd.DataFrame(columns=dict_final_cols.keys())

    # Updating/Copying columns from input to output
    for cname in dict_final_cols:
        c = list(set(dict_final_cols[cname]).intersection(set(df.columns)))
        if len(c) != 0:
            output_df[cname] = df[c[0]]

    output_df['START TIME'] = frm_start_times
    output_df['END TIME'] = frm_end_times
    output_df['END DATE'] = end_dates
    output_df["LANGUAGE"] = output_df["LANGUAGE"].fillna(value="English", inplace=None)
    output_df["SYNOPSIS"] = output_df["SYNOPSIS"].fillna(method='ffill', inplace=None)



    for i in range(len(end_dates) - 1):
        start_dt = datetime.strptime(frm_start_times[i + 1], '%H:%M')
        end_dt = datetime.strptime(frm_end_times[i], '%H:%M')
        diff = (start_dt - end_dt)
        diff2 = (end_dt - start_dt)
        diff_min=diff.seconds / 60
        diff2_min=diff2.seconds / 60
        if frm_end_times[i] == frm_start_times[i + 1]:
            #print("frm_end_times[i]",frm_end_times[i])
            #print("frm_start_times[i + 1]",frm_start_times[i + 1])
            #print(frm_start_times[i + 1], frm_end_times[i], "Success")
            continue
        elif frm_end_times[i] < frm_start_times[i + 1]:
            if diff_min <= 15.0:
                print(frm_start_times[i + 1],frm_end_times[i],"Success1")
                frm_start_times[i+1]= frm_end_times[i]
                output_df['START TIME'] = frm_start_times
            else:
                #logging.basicConfig(level=logging.WARNING, format='%(asctime)s :: %(levelname)s :: %(lineno)d :: %(message)s')
                logging.basicConfig(level=logging.WARNING,filename='myapp.log', filemode='w', format='%(asctime)s :: %(levelname)s :: %(lineno)d :: %(message)s')
                logging.warning("End time and Start time duration is more than 15min-1")
                #print(end_dates[i], frm_end_times[i], "End time and Start time duration is more than 15min")
        elif frm_start_times[i + 1] < frm_end_times[i]:
            if diff2_min <= 15.0:
                print(frm_start_times[i + 1],frm_end_times[i],"Success2")
                frm_end_times[i] = frm_start_times[i + 1]
                output_df['END TIME'] = frm_end_times
                print('output_df',output_df['END TIME'])
            else:
                logging.basicConfig(level=logging.WARNING,format='%(asctime)s :: %(levelname)s :: %(lineno)d :: %(message)s')
                logging.basicConfig(level=logging.WARNING,filename='myapp.log',filemode='w', format='%(asctime)s :: %(levelname)s :: %(lineno)d :: %(message)s')
                logging.info(frm_end_times[i],"End time and Start time duration is more than 15min-2")
                #print(end_dates[i], frm_end_times[i], "End time and Start time duration is more than 15min")
        else:
            logging.basicConfig(level=logging.WARNING,format='%(asctime)s :: %(levelname)s :: %(lineno)d :: %(message)s')
            logging.basicConfig(level=logging.WARNING,filename='myapp.log',filemode='w', format='%(asctime)s :: %(levelname)s :: %(lineno)d :: %(message)s')
            logging.info("End time and Start time duration is more than 15min-3")
            #print(end_dates[i], frm_end_times[i], "End time and Start time duration is more than 15min")

    Output_Folder_path= input("Enter Output_Folder Path :")
    files = "C:/Users/23169824/PycharmProjects/pythonProject/"+Output_Folder_path+"/"
    out_put_file_prefix = file.split(".")[0]
    out_put_file = out_put_file_prefix + '_out.csv'  # open(out_put_file_prefix + '_out.csv', 'w')
    out_put_file2= out_put_file.split("/")[-1]
    output_df.to_csv(os.path.join(files, out_put_file2),index=False)
    print(output_df.head())




if __name__ == '__main__':

    folder_path= input("Enter INPUT Folder Path :")
    files = "C:/Users/23169824/PycharmProjects/pythonProject/"+folder_path+"/"
    file=files
    for file in os.listdir(files):
        if not file.startswith("."):
            if file.endswith('.csv'):
                if not file.startswith("."):
                    print("Beeing processing", file)
                    df_comma = pd.read_csv(files + file, nrows=1, sep=",")
                    df_semi = pd.read_csv(files + file, nrows=1, sep=";")
                    xl_path = file.split("/")[-1]
                    xl_path2 = xl_path.split(".")[0]
                    if df_comma.shape[1] > df_semi.shape[1]:
                        print("comma delimited")
                        convert_epg_data_to_desire_format_type(files + file)
                    else:
                        print("semicolon delimited")
                        print("file_name",files+xl_path2+".xlsx")
                        pd.read_csv(files+file, delimiter=";", index_col=False).to_excel(files+xl_path2+".xlsx")
                        convert_epg_data_to_desire_format_type(files+xl_path2+".xlsx")
            else:
                if not file.startswith("."):
                    convert_epg_data_to_desire_format_type(files + file)
            print("Sucessfully processed", file)





